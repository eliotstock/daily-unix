# view

> A read-only version of `vim`.
> This is equivalent to `vim -R`.

- Open a file:

`view {{file}}`
