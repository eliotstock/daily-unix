# factor

> Prints the prime factorization of a number.

- Display the prime-factorization of a number:

`factor {{number}}`

- Take the input from `stdin` if no argument is specified:

`echo {{number}} | factor`
