# lscpu

> Displays information about the CPU architecture.

- Display information about all CPUs:

`lscpu`

- Display information in a table:

`lscpu --extended`

- Display only information about offline CPUs in a table:

`lscpu --extended --offline`
