# newgrp

> Switch primary group membership.

- Change user's primary group membership:

`newgrp {{group_name}}`

- Reset primary group membership to user's default group in /etc/passwd:

`newgrp`
