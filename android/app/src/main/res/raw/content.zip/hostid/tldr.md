# hostid

> Prints the numeric identifier for the current host (not necessarily the IP address).

- Display the numeric identifier for the current host in hexadecimal:

`hostid`
